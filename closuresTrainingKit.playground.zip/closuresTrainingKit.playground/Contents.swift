import UIKit
import PlaygroundSupport


let myClosure = { (name: String) -> String in
    return "Hello \(name)!"
}

let string = myClosure("Mary")
print(string)

//function that takes a closure as an argument

func runThis(closure: () -> ()) {
    closure()
}

let closure = {
    print(42)
}
//closure being passed into the function
runThis(closure: closure)
//void and () are synomyms

//common for a function to take more than one argument and a closure
//closure is typically the last argument, if it is the last argument in a function you can use trailing closure syntax, this leaves the closure out of the list or arguments, end the list before the last arguement, put the closure after the function.
//if the closure is the only argument you dont even need the ()

func sendMessageTo(name: String, message: (String) -> String) {
    print(message(name))
}
sendMessageTo(name: "Steve") { "Hello" + " " + $0 }
// if we dont create our own arguement: dollar zero means it is the 0th arguement to the closure or the first one, it knows from the function decleration in sendMessageTo that this closure will take a string and return a string, no need to retell the compliler. the compiler is also smart enough to know that the closure will return a string so we can delete return too.
    // it becomes so short it can all go on one line.

// to create a closure
// start w/ opening brace
// after brace place list of arguments in ()
// then use arrow and return type like regular function
// then in
// then write code in the body of the closure
//then call the closure and pass in the data

let closure1 = { (a: Int, b: Int) -> Int in
    return a + b
}
print(closure1(2,3))

//trailing closure syntax, function that takes a closure
func doMath(withA a: Int, b: Int, operation: (Int,Int) -> Int) -> Int {
    let result = operation(a,b)
    print("Result is \(result)")
    return operation(a,b)
}

//doMath(withA: 3, b: 7) { //(a, b) -> Int in //can remove this and return $0 and $1
    //return a + b
    //return $0 + $1
    // can simplify it even more by removing the return and placing it all on one line

doMath(withA: 3, b: 7) { $0 + $1 }

//functions are closures
func add(a: Int, b: Int) -> Int {
    return a + b
}
add(a: 3, b: 7)
// ^ this function and the closure doMath, the arguments are the same. this function can be used as if it were a closure, we can call do math and pass in add, use it's name without () we are using it as an argument so we just pass it in.

//arythmatic symbols like + is a function under the hood
//as a result the operator + can he used as a parameter and pass it in
doMath(withA: 1, b: 2, operation: +)

//write a closure that takes two a String, string and an Int, repeatCount. It should return a String consisting of the string argument repeated repeatCount times.
//For Example:
//repeat1(string: "Hello", 3) // "HelloHelloHello"


var repeat1 = { (string: String, repeatCount: Int) in
    String(repeating: string, count: repeatCount)
}
print()
let answer = repeat1("HI", 3)

print(answer)

let repeatClosure = { (string:String, repeatCount:Int) in
   
   String(repeating: string, count: repeatCount)
   
}
let repeats = repeatClosure("Stephanie",3)
print(repeats)

func repeatString2(string:String, repeatCount:Int) -> String {
  return String(repeating: string, count: repeatCount)
}
repeatString2(string: "Stephanie", repeatCount: 3)
print(repeatString2(string: "Steph", repeatCount: 4))
//higher order function is a function that takes another function as an arguement and or returns a fucntion, these functions take a closure which is really a function, as an arguement


var names = ["Andrew", "Spencer", "Erica", "Johnny", "Perez", "Jacob","Bob", "Elizabeth", "Al"]
names.sort { (string1, string2) -> Bool in
    let reversed1 = String(string1.reversed())
    let reversed2 = String(string2.reversed())
    
    if reversed1 <= reversed2 {
        return true
    } else {
        return false
    }
}
print(names)

//^ this block of code above can be condenced into one line of code
names.sort { String($0.reversed()) <= String($1.reversed()) }
print(names)


let shortNames = names.filter { (string) -> Bool in
    return string.count < 4
}
print(shortNames)

//we can shorten the code to
//let shortNames = names.filter { $0.count < 4 }

//map lets you take an array and convert every value in the array to a new value and returns the new array
var lengths : [Int] = []
for name in names {
    lengths.append(name.count)
}
print(lengths)

// we mapped every value in names to a new value in lengths.
//turned each string into the number of letters in that string
//make a new array to hold your result
//loop through everything in your original array
// transform it and append it to the new array
// this is what map does but in a lot less code

let lengths1 = names.map { (name) -> Int in
    name.count
}

print(lengths)

let lengths2 = names.map { $0.count }
print(lengths)


let strings = ["Five", "6", "123", "Forty-two"]

let numbers = strings.map {
    Int($0)
}
print(numbers)

//when we have map it will return [nil, Optional(6), Optional(123), nil] - swift isn't smart enough to read "five" and return 5 so it will return nil. to not have an array returning values of nil, you use compact map.

let numbers2 = strings.compactMap { Int($0) }
print(numbers2)
// this also unwraps the numbers and only returns
//[6, 123]
//compact map is the same as map but it handles the optional values at the same time!

let ages = [10, 42, 27, 63, 45, 33, 101]
// we want to get the average age

var sum = 0
for age in ages {
    sum += age
}
let avg = Double(sum) / Double(ages.count)
print(avg)

// we can do this^ all with reduce
//result is a placeholder for the type we want for this it is a double

//initial result = var sum = 0, the closure takes place of what we do in the for loop, it will run multiple times, every time it gets executed, the current value of the memo is passed in
let sum2 = ages.reduce(0.0) { (memo, value) -> Double in //memo will be our running sum
    return memo + Double(value)
}
let average = sum2 / Double(ages.count)
print(average)
//^ the same code can be reduced even more to
let sum3 = ages.reduce(0.0) {$0 + Double($1)}
let average3 = sum3 / Double(ages.count)
print(average3)

// if we makes ages as a double instead we no longer have to convert and can pass in + like this
let ages2: [Double] = [10, 42, 27, 63, 45, 33, 101]
let avg4 = ages2.reduce(0.0, +) / Double(ages.count) //turned 5 lines of code into 1 single line of code, however, would someone else who looked at this know what this means? this is a typical use of reduce. reduce can do a lot of things but it takes a lot to understand when just looking at it. Be careful to not lose readability.
print(avg4)

func myMap(array: [String], closure: (String) -> String) -> [String] {
    var result = [String]()
    for string in array {
        result.append(closure(string))
    }
    return result
}
let names3 = ["Andrew", "Spencer", "Erica"]
let reversedNames = myMap(array: names) { (string) -> String in
    return String(string.reversed())
}
print(reversedNames)
// can be simplified to
let reversedNames2 = myMap(array: names) { String($0.reversed()) }
print(reversedNames2)

//Concurrency allows your code to do more than one thing at the same time.
//Concurrency APIs
//POSIX Threads (pthreads)
//NSThread - object oriented, apples platform you can tell by NS
//Grand Central Dispatch - apples primary concurrency and the one we will be using
//NSOperation higher level API sim to grand central, can be used with ^ but we will use later in the course
//NSRunLoop (sort of) not for concurrency but it is the heart of every iOS App not used often but always used in the background, will mostly be using grand central

//Grand Central Dispatch - from a train metaphor
// 1 track no concurrency
// 2 or more tracks, where the code can do more than one thing
// grand central dispatch aka GCD allows you to coordinate code that is doing more than one thing

//GCD uses queues
// a queues is a lane in a road or a train tracks
// an app by default has one queue
// Main Queue - units of work, |processing UI| |IBAction| |process UI| |Animate Scrolling| |process UI| |handletap|
// it can only do one thing at a time
//to do more than one thing at a time you can have background queues so that the main queue can process ui while other things are running in the background
// while the main queues is fetching an image it can't do anything else so concurrency will allow it to fetch images and process the ui at the same time so the queue in the background will fetch the images while the main queue continues to process the UI
//now that we fetched the image we may need to process it, like filters or something and we need to be able to continue to fetch the next image and have the main queue still process the UI
//so background queue 2 will process the image, while queue 1 will fetch the next image, and the main queue will continue to animate the scrolling
//all three queues are running at the same time
//the next image will wait in the queue while the image before is being fetched or processed, depending which queue it is in
//so the UI can remain productive while the rest is happening in the background. allowing the user to still use the app while the images are processing in the background. this keeps our app moving.
//once the image has finished processing the background queue 2 will send the image via a closure to the main queue, this keeps our app functioning
//these are called serial queues, one thing after another, executes one code at a time, multiple queues allow more than one thing to happen at a time however, each queue can only do one thing at a time, so when the next image comes in it needs to wait
// a concurrent queue can have two lanes, we can convert our background queue 2 to a concurrent one.
// so while image one is still processing in lane one, lane two can start processing the second image, so then image 3 can start processing in lane one while image two is still processing and so on and so forth, then a completetion closure sends it back to the UI to be displayed. this set up creates less of a bottle neck and allows the ui to remain responsive while other things are happening in the background. the two lanes allows this to process the images much faster. this is like having multiple processors. this concurrent code takes advantage of the core processors that cpu has.
// so simplified conceptually to utilize all four cores, the main queue is using a core, then the second is using another and the last one is concurrent so it utilizing cores 3 and 4. to take advantage of the processors in mordern technology we need to use concurrancy.

//Getting a queue:
//main queue:
DispatchQueue.main

//global concurrent background queue:
DispatchQueue.global()
//global meaning it's provided for the whole application. and concurrent because it isn't a serial queue, it can run multiple closures simaltaniously.

//custom serial queue:
let serialQueue = DispatchQueue(label: "queue_name")
//if you want a serial queue that is a background queue you create your own. label is a string you create to use for debugging and for your own usage. name it based on what it is doing.

//custom concurrent queue:
let concurrentQueue = DispatchQueue(label: "queue_name", attributes: .concurrent)
//has an additional argument .concurrent, the default is .serial, if you leave it off that's what you get.

//once you have a queue you dispatch work to it, give it closures of code to execute
//two ways to do that:

//asynchronous (async) dispatch:
//queue.async { }
// async means dispatch to the target queue and immediatly continue this code


//synchronous (sync) dispatch:
//queue.sync { }
//when you dispatch a closure with the sync method it waits, this syncronizes two queues and makes it wait to process the rest of the code.

//no () because the only arguments it takes are closures and we are using trailing syntax

//you can dispatch both to either a concurrent queue or a serial queue

//async vs. sync
//examples:
//queue 1: 4 closures waiting to be executed

//queue 2: 2 closures waiting to be executed
//at the start, both will execute their first closure
//with async the queues 2 can keep working, with sync queue 2 needs to wait to run the next closure. sometimes we need to wait for a specific piece of code to run before we need can run the next closure. async is good to use when you dont need to wait, ie: they have two different purposes.

//import playground support and place this line of code in order to use concurrency in a playground.
PlaygroundPage.current.needsIndefiniteExecution = true

let queue1 = DispatchQueue(label: "queue1")
let queue2 = DispatchQueue(label: "queue2")

queue1.sync {
    print("Starting work on queue 1")
    
    queue2.async {
        print("Starting work on queue2")
        sleep(1) //this will make your code stop for one second, ****never ever ever use this in a shipping app as it is NOT the right way to use this to wait in a shipping app, this blocks the thread that you call it on. there are other ways to wait, it is okay to use in a playground
        print("Finished work on queue2")
    }
    print("Finished work on queue1")
}
print("Done")
//we actually have three queues running the main queue which is handling the print functions and then the queue1 and queue2 which are serial queues that we created.
// ^ the code above when executed will print like this:
//Starting work on queue 1
//Starting work on queue 2
//Finished work on queue 1
//Done
//Finished work on queue2

//The Main Queue:
//the main queue is used for all UIKit work
// the number one rules of iOS concurrency
//UIKit classes and methods can ONLY be used on the main queue.
//dispatch any ui code back to the main queue you can do that by using
DispatchQueue.main.async {
    //UI code here
}
//you have fetched your data and need to reload the tableview's data, it needs to be done on the main queue
DispatchQueue.main.async {
    //tableView.reloadData()
}
//if you are on an api that is forcing you to the background queue you can do
//DispatchQueue.main.async under it and then put your UI code
// dispatch back to the main queue before doing UI stuff
